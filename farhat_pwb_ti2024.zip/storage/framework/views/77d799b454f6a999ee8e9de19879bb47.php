<?php $__env->startSection('content'); ?>
<div class="hero" style="text-align:center; padding:60px 20px;">
    <article>
        <h1><?php echo e($new_berita["judul"]); ?></judul>
        <h3><?php echo e($new_berita["penulis"]); ?></h3>
        <p><?php echo e($new_berita["konten"]); ?></p>
    </article>

    <a href ="<?php echo e(url('/berita')); ?>" style="display:inline-block; padding:12px 24px; background:#00e5ff; color:#000; font-weight:bold; border-radius:8px; text-decoration:none;">Kembali</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farha\Downloads\farhat\farhat_pwb_ti2024\resources\views/singleberita.blade.php ENDPATH**/ ?>