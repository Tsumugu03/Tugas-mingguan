<?php $__env->startSection('content'); ?>
<h1>Hello, welcome to the Home Page!</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farhat\Pictures\farhat\farhat\farhat_pwb_ti2024\resources\views/home.blade.php ENDPATH**/ ?>