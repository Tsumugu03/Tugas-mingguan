<?php $__env->startSection('title', 'HOME'); ?>

<?php $__env->startSection('content'); ?>
    <div class="hero" style="text-align:center; padding:60px 20px;">
        <h1>Selamat Datang di Website Kami 🚀</h1>
        <p>Temukan informasi menarik seputar profil, berita terkini, dan cara menghubungi kami.</p>
        <a href="<?php echo e(url('/profil')); ?>" style="display:inline-block; padding:12px 24px; background:#00e5ff; color:#000; font-weight:bold; border-radius:8px; text-decoration:none;">Lihat Profil</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farha\Downloads\farhat\farhat_pwb_ti2024\resources\views/home.blade.php ENDPATH**/ ?>