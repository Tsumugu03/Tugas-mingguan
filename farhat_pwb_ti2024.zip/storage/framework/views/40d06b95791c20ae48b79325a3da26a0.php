<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Website Sederhana'); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
        }
        
        nav {
            background: #333;
            color: white;
            padding: 1rem;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            gap: 2rem;
        }
        
        nav a {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            transition: background 0.3s;
        }
        
        nav a:hover, nav a.active {
            background: #555;
            border-radius: 4px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        footer {
            background: #333;
            color: white;
            text-align: center;
            padding: 1rem;
            margin-top: 3rem;
        }
    </style>
</head>
<body>
    <nav>
        <ul>
            <li><a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Home</a></li>
            <li><a href="<?php echo e(route('berita')); ?>" class="<?php echo e(request()->routeIs('berita') ? 'active' : ''); ?>">Berita</a></li>
            <li><a href="<?php echo e(route('profile')); ?>" class="<?php echo e(request()->routeIs('profile') ? 'active' : ''); ?>">Profile</a></li>
            <li><a href="<?php echo e(route('contact')); ?>" class="<?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">Contact</a></li>
        </ul>
    </nav>
    
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
    <footer>
        <p>&copy; hehe.</p>
    </footer>
</body>
</html><?php /**PATH C:\Users\farha\Downloads\farhat\farhat_pwb_ti2024\resources\views/main.blade.php ENDPATH**/ ?>