<?php $__env->startSection('title', 'BERITA'); ?>

<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="hero" style="text-align:center; padding:60px 20px;">
<a href="/berita/<?php echo e($berita ['slug']); ?>" style="display:inline-block; padding:12px 24px; background:#C77DFF; color:#2B2B2B; font-weight:bold; border-radius:8px; text-decoration:none;" >
    <h2><?php echo e($berita['judul']); ?></h2>
</a>
<h3><?php echo e($berita['penulis']); ?></h3>
</div>
<br>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farha\Downloads\farhat\farhat_pwb_ti2024\resources\views/berita.blade.php ENDPATH**/ ?>