@extends('layouts.main')

@section('title', 'TENTANG KAMI')

@section('content')
    <div class="hero" style="text-align:center; padding:90px 20px;">
    <h1>ℹ️ Tentang Kami</h1>
    <p>Kami adalah tim yang berfokus pada pengembangan teknologi web dan aplikasi modern.</p>
    <p>Misi kami adalah menghadirkan inovasi yang bermanfaat untuk masyarakat.</p>
</div>
@endsection
